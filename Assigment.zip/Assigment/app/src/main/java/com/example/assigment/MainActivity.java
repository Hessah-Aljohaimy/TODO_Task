package com.example.assigment;

import static com.example.assigment.App.CHANNEL_1_ID;
import static com.example.assigment.App.CHANNEL_2_ID;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
private NotificationManagerCompat notificationManager;
private EditText editTextTitle;
    private EditText editTextMessage;
//Alert Button
    private Button openButton;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        notificationManager = NotificationManagerCompat.from(this);
        editTextTitle= findViewById(R.id.edit_text_title);
        editTextMessage=findViewById(R.id.edit_text_Message);

        //============= Alert Dialog ==============
        openButton  = (Button) findViewById(R.id.Reset);
        builder = new AlertDialog.Builder(this);
        openButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                //Setting meesage
                builder.setMessage("Are You Sure To Reset Notification Details ?")
                        .setTitle("Reset Notification")
                        .setPositiveButton("reset", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
//                                Boolean isSuccess= dataManager.updateLabel(labelInputDi)
                                dialogInterface.cancel();
                            }
                        })

                        .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });











                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
                alert.setTitle("Reset Notification");
                alert.show();

            }
        });

    }
    public void sendOnChannel1 (View v){
        String title = editTextTitle.getText().toString();
        String message = editTextMessage.getText().toString();


        Notification notification = new NotificationCompat.Builder(this,CHANNEL_1_ID )

                .setSmallIcon(R.drawable.ic_baseline_notification_important_24)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();
        notificationManager.notify(1,notification);
    }
    public void sendOnChannel2 (View v){
        String title = editTextTitle.getText().toString();
        String message = editTextMessage.getText().toString();


        Notification notification = new NotificationCompat.Builder(this,CHANNEL_2_ID )

                .setSmallIcon(R.drawable.ic_baseline_notifications_24)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();
        notificationManager.notify(2,notification);
    }



}